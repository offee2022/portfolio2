# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '25d7ed25738aec8496df60b8649583846f089358b92b99bae6f4aff1ac516f7df17620b5637dc8209af04bd394821d68854f9bdda34b360c69d597d41bfa5ccd'
